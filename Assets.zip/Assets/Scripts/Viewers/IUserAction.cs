﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IUserAction {
    
    void gameOver();
    void GetHit();
    
}
